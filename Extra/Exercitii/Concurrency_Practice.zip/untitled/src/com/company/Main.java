package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static int v = 0;
    public static void main(String[] args) throws Exception {
        System.out.println("before: " + v);
        List<Thread> threads = new ArrayList<>();

        for(int i =0; i < 5000; i++) {
            threads.add(new Thread());
        }
        for(int i =0; i < 5000; i++) {
            threads.get(i).start();
        }

        Thread.sleep(1000);
        System.out.print("after: " + threads.get(0).v);
    }
    static class Thread extends java.lang.Thread {
        static int v =0;

        @Override
        public synchronized void run() {
            v++;
        }
    }
}
